package com.mysite.project6.user;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserDto {

	private String userID;
	private String username;
	private String password;
	private String email;
	
}
