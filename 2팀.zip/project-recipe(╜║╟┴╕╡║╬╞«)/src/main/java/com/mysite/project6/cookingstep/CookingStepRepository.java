package com.mysite.project6.cookingstep;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CookingStepRepository extends JpaRepository<CookingStep, Integer>{

}
