package com.mysite.project6.photo;

import org.springframework.stereotype.Service;

@Service
public class PhotoService {

}
