




const reviews = [
  {
    id: 1,
    title: "Amazing Spaghetti Recipe",
    author: "Chef John",
    content: "This spaghetti recipe was amazing! My family loved it.",
    date: "2023-07-01",
  },
  {
    id: 2,
    title: "Great Chicken Curry",
    author: "Chef Emily",
    content: "The chicken curry turned out great. Highly recommend this recipe!",
    date: "2023-07-02",
  },
  // 더 많은 데이터 추가...
];

export default reviews;
